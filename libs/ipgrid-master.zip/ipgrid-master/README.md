# ipgrid - a native jQuery spreadsheet plugin

Ip.grid is a fully fledged **native jQuery spreadsheet plugin**, designed to look and feel like Google sheets. And as far as I know, is the most comprehensive spreadsheet plugin on the net.

Development is still in beta so there are a couple of bugs, you can report them on my site: 
[http://www.inspireproduction.co.za/#/contact](http://www.inspireproduction.co.za/#/contact)

***

## Basic usage

$('#demo').ip_Grid({  rows:10000, cols:26 });

## Demo & Documentation

[http://www.inspireproduction.co.za/#/demo-ui/jquery-spreadsheet](http://www.inspireproduction.co.za/#/demo-ui/jquery-spreadsheet)

## Copyright & Contact

Demo & Documentation: http://www.inspireproduction.co.za/#/demo-ui/jquery-spreadsheet

Contact me: http://www.inspireproduction.co.za/#/contact

The full contents of this code repository are (C) 2016 by Michael Roberg 


